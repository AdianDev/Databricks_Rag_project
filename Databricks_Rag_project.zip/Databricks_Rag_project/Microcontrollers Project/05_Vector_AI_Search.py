# Databricks notebook source
# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM vector_search(
# MAGIC   index => 'microcontrollers.rag_project.document_search',
# MAGIC   query_text => 'How much SRAM does RP2040 have?',
# MAGIC   num_results => 5
# MAGIC );
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM vector_search(
# MAGIC   index => 'microcontrollers.rag_project.document_search',
# MAGIC   query_text => 'What security features does RP2350 provide?',
# MAGIC   num_results => 5
# MAGIC );
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM vector_search(
# MAGIC   index => 'microcontrollers.rag_project.document_search',
# MAGIC   query_text => 'What are the main differences between RP2040 and RP2350?',
# MAGIC   num_results => 5
# MAGIC );
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM vector_search(
# MAGIC   index => 'microcontrollers.rag_project.document_search',
# MAGIC   query_text => 'What GPIO capabilities are available on RP2040?',
# MAGIC   num_results => 5
# MAGIC );
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT *
# MAGIC FROM vector_search(
# MAGIC   index => 'microcontrollers.rag_project.document_search',
# MAGIC   query_text => 'What secure boot features are available on RP2350?',
# MAGIC   num_results => 5
# MAGIC );
# MAGIC