# Databricks notebook source
# MAGIC %pip install pypdf
# MAGIC

# COMMAND ----------

# MAGIC %restart_python

# COMMAND ----------

from pypdf import PdfReader
from pyspark.sql import Row
from datetime import datetime
import os


# COMMAND ----------

SOURCE_PATH = "/Volumes/microcontrollers/rag_project/documents/"

pdf_files = [
    f.path for f in dbutils.fs.ls(SOURCE_PATH)
    if f.path.lower().endswith(".pdf")
]

print(f"Found {len(pdf_files)} PDFs")

for pdf in pdf_files:
    print(pdf)


# COMMAND ----------

pdf_binary_df = (
    spark.read
    .format("binaryFile")
    .load(SOURCE_PATH)
    .select("path", "content")
)

display(pdf_binary_df)

# COMMAND ----------

from pypdf import PdfReader
from io import BytesIO
from pyspark.sql import Row
import os

documents = []

pdf_rows = pdf_binary_df.collect()

for row in pdf_rows:

    file_name = os.path.basename(row["path"])

    # Convert Spark binary data into an in-memory file
    pdf_stream = BytesIO(row["content"])

    reader = PdfReader(pdf_stream)

    print(f"{file_name}: {len(reader.pages)} pages")

    for page_number, page in enumerate(reader.pages, start=1):

        text = page.extract_text()

        if text and text.strip():

            documents.append(
                Row(
                    file_name=file_name,
                    page_number=page_number,
                    text=text.strip()
                )
            )

print(f"\nExtracted {len(documents)} pages")


# COMMAND ----------

pages_df = spark.createDataFrame(documents)
display(pages_df)

# COMMAND ----------

display(
    pages_df
    .select("file_name", "page_number", "text")
    .limit(3)
)


# COMMAND ----------

pages_df.selectExpr(
    "count(*) as pages",
    "sum(length(text)) as total_characters",
    "avg(length(text)) as avg_characters_per_page"
).show()


# COMMAND ----------

display(
    pages_df
    .select("file_name", "page_number", "text")
    .orderBy("text")
    .limit(10)
)


# COMMAND ----------

from pyspark.sql.functions import col, when, lower, current_timestamp

pages_df = (
    pages_df
    .withColumn(
        "product",
        when(lower(col("file_name")).contains("rp2040"), "RP2040")
        .when(lower(col("file_name")).contains("rp2350"), "RP2350")
        .otherwise("Unknown")
    )
    .withColumn(
        "document_type",
        when(lower(col("file_name")).contains("datasheet"), "Datasheet")
        .when(lower(col("file_name")).contains("product-brief"), "Product Brief")
        .when(lower(col("file_name")).contains("hardware-design"), "Hardware Design")
        .when(lower(col("file_name")).contains("security"), "Security Whitepaper")
        .otherwise("Other")
    )
    .withColumn("ingested_at", current_timestamp())
)

display(pages_df)


# COMMAND ----------

(
    pages_df
    .write
    .format("delta")
    .mode("overwrite")
    .saveAsTable("microcontrollers.rag_project.document_pages")
)


# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     product,
# MAGIC     document_type,
# MAGIC     COUNT(*) AS pages
# MAGIC FROM microcontrollers.rag_project.document_pages
# MAGIC GROUP BY product, document_type
# MAGIC ORDER BY product, document_type;
# MAGIC