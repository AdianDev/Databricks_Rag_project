# Databricks notebook source
pages_df = spark.table(
    "microcontrollers.rag_project.document_pages"
)

display(pages_df)


# COMMAND ----------

from pyspark.sql import Row

chunk_rows = []

for row in pages_df.collect():

    chunks = chunk_text(
        row["text"],
        chunk_size=1500,
        overlap=200
    )

    for chunk_number, chunk in enumerate(chunks, start=1):

        if chunk and len(chunk.strip()) >= 100:

            chunk_rows.append(
                Row(
                    file_name=row["file_name"],
                    page_number=row["page_number"],
                    chunk_number=chunk_number,
                    text=chunk.strip(),
                    text_length=len(chunk.strip()),
                    product=row["product"],
                    document_type=row["document_type"]
                )
            )

print("Total chunks:", len(chunk_rows))


# COMMAND ----------

chunks_df = spark.createDataFrame(chunk_rows)

display(chunks_df.limit(10))


# COMMAND ----------

from pyspark.sql.functions import sha2, concat_ws

chunks_df = chunks_df.withColumn(
    "chunk_id",
    sha2(
        concat_ws(
            "||",
            chunks_df["file_name"],
            chunks_df["page_number"].cast("string"),
            chunks_df["chunk_number"].cast("string"),
            chunks_df["text"]
        ),
        256
    )
)


# COMMAND ----------

from pyspark.sql.functions import current_timestamp

chunks_df = chunks_df.withColumn(
    "created_at",
    current_timestamp()
)


# COMMAND ----------

chunks_df.selectExpr(
    "min(text_length) as smallest_chunk",
    "max(text_length) as largest_chunk",
    "round(avg(text_length), 0) as average_chunk_size",
    "count(*) as total_chunks"
).show()


# COMMAND ----------

(
    chunks_df
    .write
    .format("delta")
    .mode("overwrite")
    .saveAsTable(
        "microcontrollers.rag_project.document_chunks"
    )
)


# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     MIN(text_length) AS smallest_chunk,
# MAGIC     MAX(text_length) AS largest_chunk,
# MAGIC     ROUND(AVG(text_length), 0) AS average_chunk_size,
# MAGIC     COUNT(*) AS total_chunks
# MAGIC FROM microcontrollers.rag_project.document_chunks;
# MAGIC

# COMMAND ----------

