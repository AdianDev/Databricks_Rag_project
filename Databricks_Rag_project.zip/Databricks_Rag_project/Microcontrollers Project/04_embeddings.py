# Databricks notebook source
# MAGIC %sql
# MAGIC SHOW CATALOGS;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SHOW SCHEMAS IN microcontrollers;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SHOW TABLES IN microcontrollers.rag_project;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE TABLE microcontrollers.rag_project.document_chunks;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC ALTER TABLE microcontrollers.rag_project.document_chunks
# MAGIC SET TBLPROPERTIES (
# MAGIC     delta.enableChangeDataFeed = true
# MAGIC );
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SHOW TBLPROPERTIES microcontrollers.rag_project.document_chunks;
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC