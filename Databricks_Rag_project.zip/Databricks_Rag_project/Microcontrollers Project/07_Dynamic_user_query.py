# Databricks notebook source
# MAGIC %sql
# MAGIC
# MAGIC DECLARE OR REPLACE VARIABLE question STRING
# MAGIC DEFAULT 'What security features does RP2350 provide?';
# MAGIC
# MAGIC WITH retrieved AS (
# MAGIC     SELECT
# MAGIC         file_name,
# MAGIC         page_number,
# MAGIC         product,
# MAGIC         document_type,
# MAGIC         chunk_id,
# MAGIC         text,
# MAGIC         search_score
# MAGIC     FROM VECTOR_SEARCH(
# MAGIC         index => 'microcontrollers.rag_project.document_search',
# MAGIC         query_text => question,
# MAGIC         num_results => 5
# MAGIC     )
# MAGIC ),
# MAGIC
# MAGIC context AS (
# MAGIC     SELECT
# MAGIC         concat_ws(
# MAGIC             '\n\n',
# MAGIC             collect_list(
# MAGIC                 concat(
# MAGIC                     'Source: ', file_name,
# MAGIC                     '\nPage: ', CAST(page_number AS STRING),
# MAGIC                     '\nProduct: ', product,
# MAGIC                     '\nDocument type: ', document_type,
# MAGIC                     '\nContent: ', text
# MAGIC                 )
# MAGIC             )
# MAGIC         ) AS retrieved_context
# MAGIC     FROM retrieved
# MAGIC )
# MAGIC
# MAGIC SELECT ai_query(
# MAGIC     'databricks-gpt-oss-20b',
# MAGIC     concat(
# MAGIC         'You are a documentation question-answering assistant.
# MAGIC
# MAGIC Answer the user question using ONLY the retrieved documentation.
# MAGIC
# MAGIC Rules:
# MAGIC 1. Use only information explicitly supported by the retrieved documentation.
# MAGIC 2. Do not use your general knowledge.
# MAGIC 3. Do not make assumptions or infer missing specifications.
# MAGIC 4. If the retrieved documentation does not contain enough information to answer the question, say:
# MAGIC "The retrieved documentation does not contain enough information to answer this question."
# MAGIC 5. Every factual claim must be supported by the retrieved documentation.
# MAGIC 6. Do not invent citations, document names, page numbers, specifications, or features.
# MAGIC 7. At the end of the answer, provide a "Sources:" section.
# MAGIC 8. In the Sources section, list the document filename and page number for the documents that support the answer.
# MAGIC 9. Do not put citation markers such as 【】 in the answer.
# MAGIC 10. Keep the answer concise and directly answer the question.
# MAGIC
# MAGIC
# MAGIC User question:
# MAGIC ',
# MAGIC         question,
# MAGIC         '
# MAGIC
# MAGIC Retrieved documentation:
# MAGIC ',
# MAGIC         retrieved_context
# MAGIC     )
# MAGIC ) AS response
# MAGIC FROM context;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- ============================================================
# MAGIC -- RAG QUESTION
# MAGIC -- Change ONLY this value for each new question
# MAGIC -- ============================================================
# MAGIC
# MAGIC WITH params AS (
# MAGIC   SELECT 'How much SRAM does RP2040 have?' AS question
# MAGIC ),
# MAGIC
# MAGIC -- ============================================================
# MAGIC -- 1. Retrieve the most relevant document chunks
# MAGIC -- ============================================================
# MAGIC
# MAGIC retrieved_chunks AS (
# MAGIC   SELECT
# MAGIC     file_name,
# MAGIC     page_number,
# MAGIC     product,
# MAGIC     document_type,
# MAGIC     chunk_id,
# MAGIC     text,
# MAGIC     search_score
# MAGIC   FROM VECTOR_SEARCH(
# MAGIC     index => 'microcontrollers.rag_project.document_search',
# MAGIC     query_text => (SELECT question FROM params),
# MAGIC     num_results => 5
# MAGIC   )
# MAGIC ),
# MAGIC
# MAGIC -- ============================================================
# MAGIC -- 2. Combine the retrieved chunks into LLM context
# MAGIC -- ============================================================
# MAGIC
# MAGIC context AS (
# MAGIC   SELECT
# MAGIC     CONCAT_WS(
# MAGIC       '\n\n--- SOURCE ---\n',
# MAGIC       COLLECT_LIST(
# MAGIC         CONCAT(
# MAGIC           'Document: ', file_name,
# MAGIC           '\nPage: ', CAST(page_number AS STRING),
# MAGIC           '\nProduct: ', product,
# MAGIC           '\nDocument type: ', document_type,
# MAGIC           '\nContent:\n', text
# MAGIC         )
# MAGIC       )
# MAGIC     ) AS retrieved_context
# MAGIC   FROM retrieved_chunks
# MAGIC )
# MAGIC
# MAGIC -- ============================================================
# MAGIC -- 3. Ask the LLM to answer using ONLY retrieved context
# MAGIC -- ============================================================
# MAGIC
# MAGIC SELECT
# MAGIC   ai_query(
# MAGIC     'databricks-gpt-oss-20b',
# MAGIC     CONCAT(
# MAGIC       'You are a technical documentation question-answering assistant.
# MAGIC
# MAGIC ',
# MAGIC       'Your task is to answer the USER QUESTION using ONLY the RETRIEVED DOCUMENTATION.
# MAGIC
# MAGIC ',
# MAGIC       'STRICT GROUNDING RULES:
# MAGIC
# MAGIC ',
# MAGIC       '1. A retrieved chunk is NOT automatically evidence for the answer.
# MAGIC ',
# MAGIC       '2. First determine whether the retrieved documentation actually contains ',
# MAGIC       'information that directly answers the user question.
# MAGIC ',
# MAGIC       '3. Do NOT infer the meaning of numbers, names, identifiers, page numbers, ',
# MAGIC       'table-of-contents entries, or other text unless the documentation explicitly ',
# MAGIC       'establishes their meaning.
# MAGIC ',
# MAGIC       '4. Do NOT treat a number as a price, date, specification, quantity, or other ',
# MAGIC       'measurement unless the retrieved documentation explicitly identifies it as such.
# MAGIC ',
# MAGIC       '5. Do NOT use outside knowledge.
# MAGIC ',
# MAGIC       '6. Do NOT fill gaps using assumptions or general knowledge.
# MAGIC ',
# MAGIC       '7. Every factual claim in the answer must be directly supported by the retrieved ',
# MAGIC       'documentation.
# MAGIC ',
# MAGIC       '8. If the retrieved documentation does not directly contain enough information ',
# MAGIC       'to answer the question, respond exactly:
# MAGIC ',
# MAGIC       'The retrieved documentation does not contain enough information to answer this question.
# MAGIC ',
# MAGIC       '9. Cite the source document filename and page number for factual claims.
# MAGIC ',
# MAGIC       '10. Keep the answer concise.
# MAGIC ',
# MAGIC     '11. Use the minimum number of source citations necessary to support the answer.
# MAGIC ',
# MAGIC     '12. Prefer the most directly relevant page or pages over redundant citations.
# MAGIC ',
# MAGIC       'USER QUESTION:
# MAGIC ',
# MAGIC       (SELECT question FROM params),
# MAGIC       '
# MAGIC
# MAGIC ',
# MAGIC       'RETRIEVED DOCUMENTATION:
# MAGIC ',
# MAGIC       retrieved_context
# MAGIC     )
# MAGIC   ) AS response
# MAGIC FROM context;
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC WITH params AS (
# MAGIC   SELECT :question AS question
# MAGIC ),
# MAGIC
# MAGIC retrieved_chunks AS (
# MAGIC   SELECT
# MAGIC     file_name,
# MAGIC     page_number,
# MAGIC     product,
# MAGIC     document_type,
# MAGIC     chunk_id,
# MAGIC     text,
# MAGIC     search_score
# MAGIC   FROM VECTOR_SEARCH(
# MAGIC     index => 'microcontrollers.rag_project.document_search',
# MAGIC     query_text => (SELECT question FROM params),
# MAGIC     num_results => 5
# MAGIC   )
# MAGIC ),
# MAGIC
# MAGIC context AS (
# MAGIC   SELECT
# MAGIC     CONCAT_WS(
# MAGIC       '\n\n--- SOURCE ---\n',
# MAGIC       COLLECT_LIST(
# MAGIC         CONCAT(
# MAGIC           'Document: ', file_name,
# MAGIC           '\nPage: ', CAST(page_number AS STRING),
# MAGIC           '\nProduct: ', product,
# MAGIC           '\nDocument type: ', document_type,
# MAGIC           '\nContent:\n', text
# MAGIC         )
# MAGIC       )
# MAGIC     ) AS retrieved_context
# MAGIC   FROM retrieved_chunks
# MAGIC )
# MAGIC
# MAGIC SELECT
# MAGIC   ai_query(
# MAGIC     'databricks-gpt-oss-20b',
# MAGIC     CONCAT(
# MAGIC       'You are a technical documentation question-answering assistant.\n\n',
# MAGIC
# MAGIC       'Answer the user question using ONLY the retrieved documentation.\n\n',
# MAGIC
# MAGIC       'STRICT GROUNDING RULES:\n',
# MAGIC       '1. A retrieved chunk is not automatically evidence for the answer.\n',
# MAGIC       '2. Only use information that directly answers the user question.\n',
# MAGIC       '3. Do not use outside knowledge.\n',
# MAGIC       '4. Do not infer or invent technical details.\n',
# MAGIC       '5. Do not interpret unexplained numbers or identifiers.\n',
# MAGIC       '6. Every factual claim must be supported by the retrieved documentation.\n',
# MAGIC       
# MAGIC       '7. Use the minimum number of source citations necessary to support the answer.\n',
# MAGIC       '8. Prefer the most directly relevant page or pages over redundant citations.\n',
# MAGIC       '9. Cite the document filename and page number for factual claims.\n',
# MAGIC       
# MAGIC       '10. If the retrieved documentation does not contain enough information, ',
# MAGIC       'respond exactly: The retrieved documentation does not contain enough ',
# MAGIC       'information to answer this question.\n',
# MAGIC       
# MAGIC       '11. Keep the answer concise and technically accurate.\n\n',
# MAGIC
# MAGIC       'USER QUESTION:\n',
# MAGIC       (SELECT question FROM params),
# MAGIC       '\n\n',
# MAGIC
# MAGIC       'RETRIEVED DOCUMENTATION:\n',
# MAGIC       retrieved_context
# MAGIC     )
# MAGIC   ) AS response
# MAGIC FROM context;
# MAGIC