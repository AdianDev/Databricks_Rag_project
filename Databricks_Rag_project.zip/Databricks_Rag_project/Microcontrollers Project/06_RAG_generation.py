# Databricks notebook source
from databricks.sdk import WorkspaceClient

w = WorkspaceClient()

endpoints = w.serving_endpoints.list()

print("=== Available AI Model Serving Endpoints ===\n")
for ep in endpoints:
    status = "READY" if ep.state and ep.state.ready else "NOT READY"
    if ep.config and ep.config.served_entities:
        for se in ep.config.served_entities:
            model_name = se.entity_name
            model_type = "External" if se.external_model else "Foundation"
            provider = se.external_model.provider if se.external_model else "Databricks"
            print(f"Endpoint: {ep.name}")
            print(f"  Model: {model_name}")
            print(f"  Type: {model_type} | Provider: {provider} | Status: {status}")
            print()

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT ai_query(
# MAGIC   'databricks-gpt-oss-20b',
# MAGIC   'Explain in one short paragraph what the RP2040 microcontroller is.'
# MAGIC ) AS response;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC WITH retrieved AS (
# MAGIC   SELECT
# MAGIC     file_name,
# MAGIC     page_number,
# MAGIC     product,
# MAGIC     document_type,
# MAGIC     text,
# MAGIC     search_score
# MAGIC   FROM vector_search(
# MAGIC     index => 'microcontrollers.rag_project.document_search',
# MAGIC     query_text => 'How much SRAM does RP2040 have?',
# MAGIC     num_results => 5
# MAGIC   )
# MAGIC )
# MAGIC SELECT
# MAGIC   CONCAT(
# MAGIC     'SOURCE: ', file_name,
# MAGIC     ' | PAGE: ', page_number,
# MAGIC     ' | PRODUCT: ', product,
# MAGIC     ' | DOCUMENT TYPE: ', document_type,
# MAGIC     '\n',
# MAGIC     text
# MAGIC   ) AS context
# MAGIC FROM retrieved;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC WITH retrieved AS (
# MAGIC   SELECT
# MAGIC     file_name,
# MAGIC     page_number,
# MAGIC     product,
# MAGIC     document_type,
# MAGIC     text,
# MAGIC     search_score
# MAGIC   FROM vector_search(
# MAGIC     index => 'microcontrollers.rag_project.document_search',
# MAGIC     query_text => 'How much SRAM does RP2040 have?',
# MAGIC     num_results => 5
# MAGIC   )
# MAGIC ),
# MAGIC
# MAGIC context AS (
# MAGIC   SELECT
# MAGIC     array_join(
# MAGIC       collect_list(
# MAGIC         CONCAT(
# MAGIC           'SOURCE: ', file_name,
# MAGIC           ' | PAGE: ', CAST(page_number AS STRING),
# MAGIC           ' | PRODUCT: ', product,
# MAGIC           ' | DOCUMENT TYPE: ', document_type,
# MAGIC           '\n',
# MAGIC           text
# MAGIC         )
# MAGIC       ),
# MAGIC       '\n\n---\n\n'
# MAGIC     ) AS context_text
# MAGIC   FROM retrieved
# MAGIC )
# MAGIC
# MAGIC SELECT
# MAGIC   ai_query(
# MAGIC     'databricks-gpt-oss-20b',
# MAGIC     CONCAT(
# MAGIC       'You are a technical documentation assistant.
# MAGIC
# MAGIC ',
# MAGIC       'Answer the user question using ONLY the retrieved documentation below.
# MAGIC
# MAGIC ',
# MAGIC       'Rules:
# MAGIC ',
# MAGIC       '1. Do not use outside knowledge.
# MAGIC ',
# MAGIC       '2. Do not invent or infer facts that are not supported by the retrieved documentation.
# MAGIC ',
# MAGIC       '3. If the retrieved documentation does not contain enough information to answer the question, say so.
# MAGIC ',
# MAGIC       '4. Cite the source PDF filename and page number for factual claims.
# MAGIC ',
# MAGIC       '5. Keep the answer concise and technically precise.
# MAGIC
# MAGIC ',
# MAGIC       'USER QUESTION:
# MAGIC ',
# MAGIC       'How much SRAM does RP2040 have?
# MAGIC
# MAGIC ',
# MAGIC       'RETRIEVED DOCUMENTATION:
# MAGIC ',
# MAGIC       context_text
# MAGIC     )
# MAGIC   ) AS response
# MAGIC FROM context;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC WITH params AS (
# MAGIC   SELECT 'What security features does RP2350 provide?' AS question
# MAGIC ),
# MAGIC
# MAGIC retrieved AS (
# MAGIC   SELECT *
# MAGIC   FROM vector_search(
# MAGIC     index => 'microcontrollers.rag_project.document_search',
# MAGIC     query_text => (SELECT question FROM params),
# MAGIC     num_results => 5
# MAGIC   )
# MAGIC ),
# MAGIC
# MAGIC context AS (
# MAGIC   SELECT
# MAGIC     (SELECT question FROM params) AS question,
# MAGIC     array_join(
# MAGIC       collect_list(
# MAGIC         CONCAT(
# MAGIC           'SOURCE: ', file_name,
# MAGIC           ' | PAGE: ', CAST(page_number AS STRING),
# MAGIC           ' | PRODUCT: ', product,
# MAGIC           ' | DOCUMENT TYPE: ', document_type,
# MAGIC           '\n',
# MAGIC           text
# MAGIC         )
# MAGIC       ),
# MAGIC       '\n\n---\n\n'
# MAGIC     ) AS context_text
# MAGIC   FROM retrieved
# MAGIC )
# MAGIC
# MAGIC SELECT
# MAGIC   ai_query(
# MAGIC     'databricks-gpt-oss-20b',
# MAGIC     CONCAT(
# MAGIC       'You are a technical documentation assistant.
# MAGIC
# MAGIC ',
# MAGIC       'Answer the user question using ONLY the retrieved documentation below.
# MAGIC
# MAGIC ',
# MAGIC       'Rules:
# MAGIC ',
# MAGIC       '1. Do not use outside knowledge.
# MAGIC ',
# MAGIC       '2. Do not invent facts.
# MAGIC ',
# MAGIC       '3. If the documentation does not contain enough information, say so.
# MAGIC ',
# MAGIC       '4. Cite the source PDF filename and page number for factual claims.
# MAGIC ',
# MAGIC       '5. Keep the answer concise and technically precise.
# MAGIC
# MAGIC ',
# MAGIC       'USER QUESTION:
# MAGIC ',
# MAGIC       question,
# MAGIC       '
# MAGIC
# MAGIC RETRIEVED DOCUMENTATION:
# MAGIC ',
# MAGIC       context_text
# MAGIC     )
# MAGIC   ) AS response
# MAGIC FROM context;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC WITH retrieved AS (
# MAGIC   SELECT
# MAGIC     file_name,
# MAGIC     page_number,
# MAGIC     product,
# MAGIC     document_type,
# MAGIC     text,
# MAGIC     search_score
# MAGIC   FROM vector_search(
# MAGIC     index => 'microcontrollers.rag_project.document_search',
# MAGIC     query_text => 'What security features does RP2350 provide?',
# MAGIC     num_results => 5
# MAGIC   )
# MAGIC ),
# MAGIC
# MAGIC context AS (
# MAGIC   SELECT
# MAGIC     array_join(
# MAGIC       collect_list(
# MAGIC         CONCAT(
# MAGIC           'SOURCE: ', file_name,
# MAGIC           ' | PAGE: ', CAST(page_number AS STRING),
# MAGIC           ' | PRODUCT: ', product,
# MAGIC           ' | DOCUMENT TYPE: ', document_type,
# MAGIC           '\n',
# MAGIC           text
# MAGIC         )
# MAGIC       ),
# MAGIC       '\n\n---\n\n'
# MAGIC     ) AS context_text
# MAGIC   FROM retrieved
# MAGIC )
# MAGIC
# MAGIC SELECT
# MAGIC   ai_query(
# MAGIC     'databricks-gpt-oss-20b',
# MAGIC     CONCAT(
# MAGIC       'You are a technical documentation RAG assistant.
# MAGIC
# MAGIC ',
# MAGIC       'IMPORTANT: The retrieved documentation below is the ONLY source of truth.
# MAGIC
# MAGIC ',
# MAGIC       'Grounding rules:
# MAGIC ',
# MAGIC       '- Use only information explicitly stated in the retrieved documentation.
# MAGIC ',
# MAGIC       '- Do not use your pretrained knowledge or outside information.
# MAGIC ',
# MAGIC       '- Do not add examples, specifications, explanations, or interpretations that are not explicitly present in the retrieved text.
# MAGIC ',
# MAGIC       '- Do not infer missing details.
# MAGIC ',
# MAGIC       '- If the retrieved documentation does not provide enough information, explicitly say that the information is not available in the retrieved context.
# MAGIC ',
# MAGIC       '- Every factual claim must include a citation in this exact format: [Source: filename, p. X].
# MAGIC ',
# MAGIC       '- Keep the answer concise and technically precise.
# MAGIC
# MAGIC ',
# MAGIC       'USER QUESTION:
# MAGIC ',
# MAGIC       'What security features does RP2350 provide?
# MAGIC
# MAGIC ',
# MAGIC       'RETRIEVED DOCUMENTATION:
# MAGIC ',
# MAGIC       context_text
# MAGIC     )
# MAGIC   ) AS response
# MAGIC FROM context;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC   file_name,
# MAGIC   page_number,
# MAGIC   product,
# MAGIC   document_type,
# MAGIC   chunk_id,
# MAGIC   search_score
# MAGIC FROM vector_search(
# MAGIC   index => 'microcontrollers.rag_project.document_search',
# MAGIC   query_text => 'What security features does RP2350 provide?',
# MAGIC   num_results => 5
# MAGIC );
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC     file_name,
# MAGIC     page_number,
# MAGIC     product,
# MAGIC     document_type,
# MAGIC     chunk_id,
# MAGIC     text,
# MAGIC     search_score
# MAGIC FROM VECTOR_SEARCH(
# MAGIC     index => 'microcontrollers.rag_project.document_search',
# MAGIC     query_text => 'What security features does RP2350 provide?',
# MAGIC     num_results => 5
# MAGIC )
# MAGIC ORDER BY search_score DESC;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC DECLARE OR REPLACE VARIABLE user_question STRING
# MAGIC DEFAULT 'What security features does RP2350 provide?';
# MAGIC
# MAGIC WITH retrieved AS (
# MAGIC     SELECT
# MAGIC         file_name,
# MAGIC         page_number,
# MAGIC         product,
# MAGIC         document_type,
# MAGIC         chunk_id,
# MAGIC         text,
# MAGIC         search_score
# MAGIC     FROM VECTOR_SEARCH(
# MAGIC         index => 'microcontrollers.rag_project.document_search',
# MAGIC         query_text => user_question,
# MAGIC         num_results => 5
# MAGIC     )
# MAGIC ),
# MAGIC
# MAGIC context AS (
# MAGIC     SELECT
# MAGIC         concat_ws(
# MAGIC             '\n\n',
# MAGIC             collect_list(
# MAGIC                 concat(
# MAGIC                     'SOURCE: ', file_name,
# MAGIC                     ' | PAGE: ', CAST(page_number AS STRING),
# MAGIC                     ' | PRODUCT: ', product,
# MAGIC                     ' | DOCUMENT TYPE: ', document_type,
# MAGIC                     '\n',
# MAGIC                     text
# MAGIC                 )
# MAGIC             )
# MAGIC         ) AS retrieved_context
# MAGIC     FROM retrieved
# MAGIC )
# MAGIC
# MAGIC SELECT
# MAGIC     ai_query(
# MAGIC         'databricks-gpt-oss-20b',
# MAGIC         concat(
# MAGIC             'You are a technical documentation assistant for RP2040 and RP2350. ',
# MAGIC             'Answer the user question using ONLY the retrieved documentation provided below. ',
# MAGIC             'Do not use outside knowledge. ',
# MAGIC             'Do not invent specifications, features, numbers, or explanations. ',
# MAGIC             'If the retrieved documentation does not contain enough information, ',
# MAGIC             'clearly say that the provided documentation does not contain enough information. ',
# MAGIC             'For factual claims, cite the source using this format: ',
# MAGIC             '[Source: filename, page N]. ',
# MAGIC             'Use the page number provided in the retrieved context. ',
# MAGIC             '\n\nUSER QUESTION:\n',
# MAGIC             user_question,
# MAGIC             '\n\nRETRIEVED DOCUMENTATION:\n',
# MAGIC             retrieved_context
# MAGIC         )
# MAGIC     ) AS response
# MAGIC FROM context;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC DECLARE OR REPLACE VARIABLE user_question STRING
# MAGIC DEFAULT 'How much SRAM does RP2040 have?';
# MAGIC
# MAGIC WITH retrieved AS (
# MAGIC     SELECT
# MAGIC         file_name,
# MAGIC         page_number,
# MAGIC         product,
# MAGIC         document_type,
# MAGIC         chunk_id,
# MAGIC         text,
# MAGIC         search_score
# MAGIC     FROM VECTOR_SEARCH(
# MAGIC         index => 'microcontrollers.rag_project.document_search',
# MAGIC         query_text => user_question,
# MAGIC         num_results => 5
# MAGIC     )
# MAGIC ),
# MAGIC
# MAGIC context AS (
# MAGIC     SELECT
# MAGIC         concat_ws(
# MAGIC             '\n\n',
# MAGIC             collect_list(
# MAGIC                 concat(
# MAGIC                     'SOURCE: ', file_name,
# MAGIC                     ' | PAGE: ', CAST(page_number AS STRING),
# MAGIC                     ' | PRODUCT: ', product,
# MAGIC                     ' | DOCUMENT TYPE: ', document_type,
# MAGIC                     '\n',
# MAGIC                     text
# MAGIC                 )
# MAGIC             )
# MAGIC         ) AS retrieved_context
# MAGIC     FROM retrieved
# MAGIC )
# MAGIC
# MAGIC SELECT
# MAGIC     ai_query(
# MAGIC         'databricks-gpt-oss-20b',
# MAGIC         concat(
# MAGIC             'You are a technical documentation assistant for RP2040 and RP2350. ',
# MAGIC             'Answer the user question using ONLY the retrieved documentation provided below. ',
# MAGIC             'Do not use outside knowledge. ',
# MAGIC             'Do not invent specifications, features, numbers, or explanations. ',
# MAGIC             'If the retrieved documentation does not contain enough information, ',
# MAGIC             'clearly say that the provided documentation does not contain enough information. ',
# MAGIC             'For factual claims, cite the source using this format: ',
# MAGIC             '[Source: filename, page N]. ',
# MAGIC             'Use the page number provided in the retrieved context. ',
# MAGIC             '\n\nUSER QUESTION:\n',
# MAGIC             user_question,
# MAGIC             '\n\nRETRIEVED DOCUMENTATION:\n',
# MAGIC             retrieved_context
# MAGIC         )
# MAGIC     ) AS response
# MAGIC FROM context;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC DECLARE OR REPLACE VARIABLE user_question STRING
# MAGIC DEFAULT 'What security features does RP2350 provide?';
# MAGIC
# MAGIC WITH retrieved AS (
# MAGIC     SELECT
# MAGIC         file_name,
# MAGIC         page_number,
# MAGIC         product,
# MAGIC         document_type,
# MAGIC         chunk_id,
# MAGIC         text,
# MAGIC         search_score
# MAGIC     FROM VECTOR_SEARCH(
# MAGIC         index => 'microcontrollers.rag_project.document_search',
# MAGIC         query_text => user_question,
# MAGIC         num_results => 5
# MAGIC     )
# MAGIC ),
# MAGIC
# MAGIC context AS (
# MAGIC     SELECT
# MAGIC         concat_ws(
# MAGIC             '\n\n--- DOCUMENT CHUNK ---\n\n',
# MAGIC             collect_list(
# MAGIC                 concat(
# MAGIC                     'SOURCE FILE: ', file_name,
# MAGIC                     '\nPAGE: ', CAST(page_number AS STRING),
# MAGIC                     '\nPRODUCT: ', product,
# MAGIC                     '\nDOCUMENT TYPE: ', document_type,
# MAGIC                     '\nCHUNK ID: ', chunk_id,
# MAGIC                     '\n\nTEXT:\n',
# MAGIC                     text
# MAGIC                 )
# MAGIC             )
# MAGIC         ) AS retrieved_context
# MAGIC     FROM retrieved
# MAGIC )
# MAGIC
# MAGIC SELECT
# MAGIC     ai_query(
# MAGIC         'databricks-gpt-oss-20b',
# MAGIC         concat(
# MAGIC             'You are a technical documentation assistant for RP2040 and RP2350. ',
# MAGIC             '\n\n',
# MAGIC             'STRICT GROUNDING RULES:',
# MAGIC             '\n1. Answer using ONLY information explicitly stated in the retrieved documentation.',
# MAGIC             '\n2. Do not use your general or pretrained knowledge.',
# MAGIC             '\n3. Do not infer, extrapolate, or fill in missing technical details.',
# MAGIC             '\n4. Do not introduce technical terms, specifications, algorithms, hardware blocks, ',
# MAGIC             'or capabilities unless they are explicitly supported by the retrieved text.',
# MAGIC             '\n5. Every factual claim must be supported by one or more retrieved document chunks.',
# MAGIC             '\n6. Cite the source file and page that support each factual claim.',
# MAGIC             '\n7. If the retrieved documentation does not contain enough information, say so clearly.',
# MAGIC             '\n8. Do not cite a page merely because it is related to the topic; the cited page must support the claim.',
# MAGIC             '\n\n',
# MAGIC             'CITATION FORMAT:',
# MAGIC             '\nUse exactly this format:',
# MAGIC             '[Source: filename, page N]',
# MAGIC             '\n\n',
# MAGIC             'USER QUESTION:',
# MAGIC             '\n',
# MAGIC             user_question,
# MAGIC             '\n\n',
# MAGIC             'RETRIEVED DOCUMENTATION:',
# MAGIC             '\n',
# MAGIC             retrieved_context
# MAGIC         )
# MAGIC     ) AS response
# MAGIC FROM context;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC DECLARE OR REPLACE VARIABLE user_question STRING
# MAGIC DEFAULT 'How much SRAM does RP2040 have?';
# MAGIC
# MAGIC WITH retrieved AS (
# MAGIC     SELECT
# MAGIC         file_name,
# MAGIC         page_number,
# MAGIC         product,
# MAGIC         document_type,
# MAGIC         chunk_id,
# MAGIC         text,
# MAGIC         search_score
# MAGIC     FROM VECTOR_SEARCH(
# MAGIC         index => 'microcontrollers.rag_project.document_search',
# MAGIC         query_text => user_question,
# MAGIC         num_results => 5
# MAGIC     )
# MAGIC ),
# MAGIC
# MAGIC context AS (
# MAGIC     SELECT
# MAGIC         concat_ws(
# MAGIC             '\n\n--- DOCUMENT CHUNK ---\n\n',
# MAGIC             collect_list(
# MAGIC                 concat(
# MAGIC                     'SOURCE FILE: ', file_name,
# MAGIC                     '\nPAGE: ', CAST(page_number AS STRING),
# MAGIC                     '\nPRODUCT: ', product,
# MAGIC                     '\nDOCUMENT TYPE: ', document_type,
# MAGIC                     '\nCHUNK ID: ', chunk_id,
# MAGIC                     '\n\nTEXT:\n',
# MAGIC                     text
# MAGIC                 )
# MAGIC             )
# MAGIC         ) AS retrieved_context
# MAGIC     FROM retrieved
# MAGIC )
# MAGIC
# MAGIC SELECT
# MAGIC     ai_query(
# MAGIC         'databricks-gpt-oss-20b',
# MAGIC         concat(
# MAGIC             'You are a technical documentation assistant for RP2040 and RP2350. ',
# MAGIC             '\n\n',
# MAGIC             'STRICT GROUNDING RULES:',
# MAGIC             '\n1. Answer using ONLY information explicitly stated in the retrieved documentation.',
# MAGIC             '\n2. Do not use your general or pretrained knowledge.',
# MAGIC             '\n3. Do not infer, extrapolate, or fill in missing technical details.',
# MAGIC             '\n4. Do not introduce technical terms, specifications, algorithms, hardware blocks, ',
# MAGIC             'or capabilities unless they are explicitly supported by the retrieved text.',
# MAGIC             '\n5. Every factual claim must be supported by one or more retrieved document chunks.',
# MAGIC             '\n6. Cite the source file and page that support each factual claim.',
# MAGIC             '\n7. If the retrieved documentation does not contain enough information, say so clearly.',
# MAGIC             '\n8. Do not cite a page merely because it is related to the topic; the cited page must support the claim.',
# MAGIC             '\n\n',
# MAGIC             'CITATION FORMAT:',
# MAGIC             '\nUse exactly this format:',
# MAGIC             '[Source: filename, page N]',
# MAGIC             '\n\n',
# MAGIC             'USER QUESTION:',
# MAGIC             '\n',
# MAGIC             user_question,
# MAGIC             '\n\n',
# MAGIC             'RETRIEVED DOCUMENTATION:',
# MAGIC             '\n',
# MAGIC             retrieved_context
# MAGIC         )
# MAGIC     ) AS response
# MAGIC FROM context;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC DECLARE OR REPLACE VARIABLE user_question STRING
# MAGIC DEFAULT 'What are the main differences between RP2040 and RP2350?';
# MAGIC
# MAGIC WITH retrieved AS (
# MAGIC     SELECT
# MAGIC         file_name,
# MAGIC         page_number,
# MAGIC         product,
# MAGIC         document_type,
# MAGIC         chunk_id,
# MAGIC         text,
# MAGIC         search_score
# MAGIC     FROM VECTOR_SEARCH(
# MAGIC         index => 'microcontrollers.rag_project.document_search',
# MAGIC         query_text => user_question,
# MAGIC         num_results => 5
# MAGIC     )
# MAGIC ),
# MAGIC
# MAGIC context AS (
# MAGIC     SELECT
# MAGIC         concat_ws(
# MAGIC             '\n\n--- DOCUMENT CHUNK ---\n\n',
# MAGIC             collect_list(
# MAGIC                 concat(
# MAGIC                     'SOURCE FILE: ', file_name,
# MAGIC                     '\nPAGE: ', CAST(page_number AS STRING),
# MAGIC                     '\nPRODUCT: ', product,
# MAGIC                     '\nDOCUMENT TYPE: ', document_type,
# MAGIC                     '\nCHUNK ID: ', chunk_id,
# MAGIC                     '\n\nTEXT:\n',
# MAGIC                     text
# MAGIC                 )
# MAGIC             )
# MAGIC         ) AS retrieved_context
# MAGIC     FROM retrieved
# MAGIC ),
# MAGIC
# MAGIC answer AS (
# MAGIC     SELECT
# MAGIC         ai_query(
# MAGIC             'databricks-gpt-oss-20b',
# MAGIC             concat(
# MAGIC                 'You are a technical documentation assistant for RP2040 and RP2350.',
# MAGIC                 '\n\nSTRICT GROUNDING RULES:',
# MAGIC                 '\n1. Answer using ONLY information explicitly stated in the retrieved documentation.',
# MAGIC                 '\n2. Do not use general or pretrained knowledge.',
# MAGIC                 '\n3. Do not infer or extrapolate missing technical details.',
# MAGIC                 '\n4. Do not introduce specifications or capabilities unless supported by the retrieved text.',
# MAGIC                 '\n5. Every factual claim must be supported by retrieved documentation.',
# MAGIC                 '\n6. Cite the source file and page supporting each factual claim.',
# MAGIC                 '\n7. If the documentation is insufficient, say so.',
# MAGIC                 '\n8. Do not cite a page unless it supports the claim.',
# MAGIC                 '\n\nCITATION FORMAT:',
# MAGIC                 '\n[Source: filename, page N]',
# MAGIC                 '\n\nUSER QUESTION:',
# MAGIC                 '\n',
# MAGIC                 user_question,
# MAGIC                 '\n\nRETRIEVED DOCUMENTATION:',
# MAGIC                 '\n',
# MAGIC                 retrieved_context
# MAGIC             )
# MAGIC         ) AS response
# MAGIC     FROM context
# MAGIC )
# MAGIC
# MAGIC SELECT
# MAGIC     response
# MAGIC FROM answer;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC WITH retrieved AS (
# MAGIC     SELECT
# MAGIC         file_name,
# MAGIC         page_number,
# MAGIC         product,
# MAGIC         document_type,
# MAGIC         chunk_id,
# MAGIC         text,
# MAGIC         search_score
# MAGIC     FROM VECTOR_SEARCH(
# MAGIC         index => 'microcontrollers.rag_project.document_search',
# MAGIC         query_text => 'YOUR QUESTION',
# MAGIC         num_results => 5
# MAGIC     )
# MAGIC ),
# MAGIC
# MAGIC context AS (
# MAGIC     SELECT
# MAGIC         concat_ws(
# MAGIC             '\n\n',
# MAGIC             collect_list(
# MAGIC                 concat(
# MAGIC                     'Source: ', file_name,
# MAGIC                     '\nPage: ', page_number,
# MAGIC                     '\nProduct: ', product,
# MAGIC                     '\nContent: ', text
# MAGIC                 )
# MAGIC             )
# MAGIC         ) AS retrieved_context
# MAGIC     FROM retrieved
# MAGIC )
# MAGIC
# MAGIC SELECT ai_query(
# MAGIC     'databricks-gpt-oss-20b',
# MAGIC     concat(
# MAGIC         'You are a documentation question-answering assistant.
# MAGIC
# MAGIC Answer ONLY using the retrieved documentation.
# MAGIC
# MAGIC Rules:
# MAGIC 1. Do not use outside knowledge.
# MAGIC 2. Do not invent facts.
# MAGIC 3. Do not infer specifications that are not explicitly stated.
# MAGIC 4. Cite every factual claim using document name and page number.
# MAGIC 5. If the answer is not supported by the retrieved documentation, say:
# MAGIC    "The retrieved documentation does not contain enough information to answer this question."
# MAGIC
# MAGIC User question:
# MAGIC ',
# MAGIC         'How much SRAM does RP2040 have?',
# MAGIC         '
# MAGIC
# MAGIC Retrieved documentation:
# MAGIC ',
# MAGIC         retrieved_context
# MAGIC     )
# MAGIC ) AS response
# MAGIC FROM context;
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC
# MAGIC WITH retrieved AS (
# MAGIC     SELECT
# MAGIC         file_name,
# MAGIC         page_number,
# MAGIC         product,
# MAGIC         document_type,
# MAGIC         chunk_id,
# MAGIC         text,
# MAGIC         search_score
# MAGIC     FROM VECTOR_SEARCH(
# MAGIC         index => 'microcontrollers.rag_project.document_search',
# MAGIC         query_text => 'How much SRAM does RP2040 have?',
# MAGIC         num_results => 5
# MAGIC     )
# MAGIC ),
# MAGIC
# MAGIC context AS (
# MAGIC     SELECT
# MAGIC         concat_ws(
# MAGIC             '\n\n',
# MAGIC             collect_list(
# MAGIC                 concat(
# MAGIC                     'Source: ', file_name,
# MAGIC                     '\nPage: ', CAST(page_number AS STRING),
# MAGIC                     '\nProduct: ', product,
# MAGIC                     '\nDocument type: ', document_type,
# MAGIC                     '\nContent: ', text
# MAGIC                 )
# MAGIC             )
# MAGIC         ) AS retrieved_context
# MAGIC     FROM retrieved
# MAGIC )
# MAGIC
# MAGIC SELECT ai_query(
# MAGIC     'databricks-gpt-oss-20b',
# MAGIC     concat(
# MAGIC         'You are a documentation question-answering assistant.
# MAGIC
# MAGIC Answer the user question using ONLY the retrieved documentation.
# MAGIC
# MAGIC Rules:
# MAGIC 1. Use only information explicitly supported by the retrieved documentation.
# MAGIC 2. Do not use your general knowledge.
# MAGIC 3. Do not make assumptions or infer missing specifications.
# MAGIC 4. If the retrieved documentation does not contain enough information to answer the question, say:
# MAGIC "The retrieved documentation does not contain enough information to answer this question."
# MAGIC 5. Every factual claim should include the source document name and page number.
# MAGIC 6. Do not invent citations.
# MAGIC 7. Keep the answer concise and directly answer the user question.
# MAGIC
# MAGIC User question:
# MAGIC How much SRAM does RP2040 have?
# MAGIC
# MAGIC Retrieved documentation:
# MAGIC ',
# MAGIC         retrieved_context
# MAGIC     )
# MAGIC ) AS response
# MAGIC FROM context;
# MAGIC