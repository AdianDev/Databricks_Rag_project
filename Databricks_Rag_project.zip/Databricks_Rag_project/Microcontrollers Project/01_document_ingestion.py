# Databricks notebook source
CATALOG = "microcontrollers"
SCHEMA = "rag_project"
VOLUME = "documents"

SOURCE_PATH = f"/Volumes/{CATALOG}/{SCHEMA}/{VOLUME}/"

print(SOURCE_PATH)


# COMMAND ----------

files = dbutils.fs.ls(SOURCE_PATH)

for file in files:
    print(file.path)


# COMMAND ----------

pdf_files = [
    f.path for f in dbutils.fs.ls(SOURCE_PATH)
    if f.path.lower().endswith(".pdf")
]

print(f"Found {len(pdf_files)} PDF files:")

for pdf in pdf_files:
    print(pdf)
